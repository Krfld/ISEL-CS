#ifndef _CONFIG_H_
#define _CONFIG_H_


#define APP_NAME "ewallet"

#define WALLET_FILE "ewallet.db"

#define WALLET_MAX_ITEMS 100
#define WALLET_MAX_ITEM_SIZE 100

#endif // !_CONFIG_H_
