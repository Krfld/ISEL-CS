#ifndef _ENCLAVE_H_
#define _ENCLAVE_H_

int printf( const char *fmt, ... );

#endif /* !_ENCLAVE_H_ */
